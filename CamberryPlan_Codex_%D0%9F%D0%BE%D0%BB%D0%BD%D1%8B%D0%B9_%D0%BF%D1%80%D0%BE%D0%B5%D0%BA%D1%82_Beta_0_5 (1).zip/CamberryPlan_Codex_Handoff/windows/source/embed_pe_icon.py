#!/usr/bin/env python3
"""Add a valid RT_ICON/RT_GROUP_ICON PE resource section using only stdlib.

Designed for unsigned Go-built 64-bit GUI PE executables. We do not change
program code or imports. The resources use standard Windows PE directory
structures and are displayed by Explorer, taskbar and application title bars.
"""
import struct
from pathlib import Path
import sys

def round_up(n,a):return ((n+a-1)//a)*a

def parse_ico(path):
 ico=Path(path).read_bytes()
 zero,typ,n=struct.unpack_from('<HHH',ico,0)
 assert (zero,typ)==(0,1) and n>=1
 images=[]; group=bytearray(struct.pack('<HHH',0,1,n))
 for i in range(n):
  width,height,colors,reserved,planes,bits,size,offset=struct.unpack_from('<BBBBHHII',ico,6+i*16)
  images.append(ico[offset:offset+size])
  group += struct.pack('<BBBBHHIH',width,height,colors,reserved,planes,bits,size,i+1)
 return images,bytes(group)

class Builder:
 def __init__(self):self.b=bytearray()
 def alloc(self,n):
  at=round_up(len(self.b),4)
  if at>len(self.b):self.b.extend(b'\0'*(at-len(self.b)))
  self.b.extend(b'\0'*n)
  return at
 def put(self,p,fmt,*vals):struct.pack_into(fmt,self.b,p,*vals)
 def dir(self,n):
  p=self.alloc(16+n*8)
  self.put(p,'<IIHHHH',0,0,0,0,0,n)
  return p
 def ent(self,p,i,id,offs,is_dir):self.put(p+16+i*8,'<II',id,offs|(0x80000000 if is_dir else 0))
 def data_entry(self,p,rva,size):self.put(p,'<IIII',rva,size,0,0)

def resource_blob(images,group,section_rva):
 b=Builder()
 root=b.dir(2)
 icon_dir=b.dir(len(images));group_dir=b.dir(1)
 b.ent(root,0,3,icon_dir,True);b.ent(root,1,14,group_dir,True)
 ico_langs=[];ico_data_entries=[]
 for i in range(len(images)):
  lang=b.dir(1); d=b.alloc(16)
  b.ent(icon_dir,i,i+1,lang,True)
  b.ent(lang,0,1033,d,False)
  ico_langs.append(lang);ico_data_entries.append(d)
 group_lang=b.dir(1);group_de=b.alloc(16)
 b.ent(group_dir,0,1,group_lang,True);b.ent(group_lang,0,1033,group_de,False)
 for img,d in zip(images,ico_data_entries):
  offs=b.alloc(len(img));b.b[offs:offs+len(img)]=img
  b.data_entry(d,section_rva+offs,len(img))
 offs=b.alloc(len(group));b.b[offs:offs+len(group)]=group
 b.data_entry(group_de,section_rva+offs,len(group))
 return bytes(b.b)

def patch(exepath,icopath):
 path=Path(exepath)
 content=bytearray(path.read_bytes())
 pe=struct.unpack_from('<I',content,0x3c)[0]
 assert content[pe:pe+4]==b'PE\0\0'
 coff=pe+4
 machine,nsec=struct.unpack_from('<HH',content,coff)
 assert machine==0x8664
 opts=coff+20
 optsize=struct.unpack_from('<H',content,coff+16)[0]
 assert struct.unpack_from('<H',content,opts)[0]==0x20b
 sect=opts+optsize
 secs=[]
 for i in range(nsec):
  off=sect+i*40
  name=bytes(content[off:off+8]).split(b'\0')[0]
  virt_size,rva,raw_size,raw_ptr=struct.unpack_from('<IIII',content,off+8)
  secs.append((name,virt_size,rva,raw_size,raw_ptr))
 assert all(name != b'.rsrc' for name,*_ in secs)
 assert sect+(nsec+1)*40 <= struct.unpack_from('<I',content,opts+60)[0], 'No room for new section header'
 va_align,fa_align=struct.unpack_from('<II',content,opts+32)
 last_rva=max(round_up(s[2]+max(s[1],s[3]),va_align) for s in secs)
 data_offset=round_up(len(content),fa_align)
 images,group=parse_ico(icopath)
 blob=resource_blob(images,group,last_rva)
 rawlen=round_up(len(blob),fa_align)
 if len(content)<data_offset:content.extend(b'\0'*(data_offset-len(content)))
 content+=blob+b'\0'*(rawlen-len(blob))
 off=sect+nsec*40
 struct.pack_into('<8sIIIIIIHHI',content,off,b'.rsrc\0\0\0',len(blob),last_rva,rawlen,data_offset,0,0,0,0,0x40000040)
 struct.pack_into('<H',content,coff+2,nsec+1)
 struct.pack_into('<I',content,opts+56,round_up(last_rva+len(blob),va_align)) # SizeOfImage
 prev_init=struct.unpack_from('<I',content,opts+8)[0]
 struct.pack_into('<I',content,opts+8,prev_init+rawlen)
 struct.pack_into('<II',content,opts+112+2*8,last_rva,len(blob))
 path.write_bytes(content)
 print('Embedded',len(images),'sizes of icon into',path.name,'PE .rsrc',len(blob),'bytes')

if __name__=='__main__':patch(sys.argv[1],sys.argv[2])
