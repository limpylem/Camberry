// CamberryPlan for Windows — offline desktop launcher.
// Uses the locally installed Microsoft Edge / Chrome in application mode.
// No network services, accounts or external dependencies are required.
package main

import (
    "embed"
    "fmt"
    "net/url"
    "os"
    "os/exec"
    "path/filepath"
    "strings"
    "syscall"
    "unsafe"
)

//go:embed html/index.html
var appFS embed.FS

var user32 = syscall.NewLazyDLL("user32.dll")
var procMessageBox = user32.NewProc("MessageBoxW")

func popup(title, message string) {
    procMessageBox.Call(0, uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(message))), uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(title))), 0x10)
}

func browserCandidates() []string {
    pf := os.Getenv("ProgramFiles")
    pf86 := os.Getenv("ProgramFiles(x86)")
    la := os.Getenv("LOCALAPPDATA")
    return []string{
        filepath.Join(pf86,"Microsoft", "Edge", "Application", "msedge.exe"),
        filepath.Join(pf,"Microsoft", "Edge", "Application", "msedge.exe"),
        filepath.Join(la,"Microsoft", "Edge", "Application", "msedge.exe"),
        filepath.Join(pf,"Google", "Chrome", "Application", "chrome.exe"),
        filepath.Join(pf86,"Google", "Chrome", "Application", "chrome.exe"),
        filepath.Join(la,"Google", "Chrome", "Application", "chrome.exe"),
    }
}
func fileURL(name string) string {
    norm := filepath.ToSlash(name)
    return (&url.URL{Scheme:"file", Path:"/" + norm}).String()
}
func main() {
    local := os.Getenv("LOCALAPPDATA")
    if local=="" { popup("CamberryPlan", "Не удалось найти папку AppData пользователя.");return }
    appDir := filepath.Join(local,"CamberryPlan","App")
    profile := filepath.Join(local,"CamberryPlan","BrowserProfile")
    if err:=os.MkdirAll(appDir,0755);err!=nil {popup("CamberryPlan", "Нельзя создать папку приложения: "+err.Error());return}
    if err:=os.MkdirAll(profile,0755);err!=nil {popup("CamberryPlan", "Нельзя создать папку профиля: "+err.Error());return}
    indexPath:=filepath.Join(appDir,"index.html")
    data,err:=appFS.ReadFile("html/index.html")
    if err!=nil { popup("CamberryPlan", "Файлы приложения недоступны.");return }
    // Keep this path constant across versions so locally saved plans remain available.
    if err:=os.WriteFile(indexPath,data,0644);err!=nil {popup("CamberryPlan", "Не удалось обновить приложение: "+err.Error());return}
    uri:=fileURL(indexPath)
    for _,name:=range browserCandidates() {
        if _,err:=os.Stat(name);err!=nil { continue }
        cmd:=exec.Command(name,"--app="+uri,"--user-data-dir="+profile,"--window-size=1340,900","--no-first-run","--no-default-browser-check")
        cmd.SysProcAttr=&syscall.SysProcAttr{HideWindow:true}
        if err:=cmd.Start();err==nil {return}
    }
    // Fallback: attempt to open the embedded plan in the default browser.
    // Note that app-mode requires Microsoft Edge or Google Chrome.
    cmd:=exec.Command("rundll32.exe","url.dll,FileProtocolHandler",uri)
    cmd.SysProcAttr=&syscall.SysProcAttr{HideWindow:true}
    if err:=cmd.Start();err!=nil {
        popup("CamberryPlan", fmt.Sprintf("Для работы нужен Microsoft Edge или Chrome.\n\nПлан сохранён в:\n%s\n\n%s", indexPath, strings.TrimSpace(err.Error())))
    }
}
