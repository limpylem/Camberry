// CamberryPlan Setup for Windows 10/11 (x64).
// Native per-user Windows installer, no administrator permission needed.
// Installs standalone launcher & custom icon, Start Menu + optional Desktop
// shortcuts, and standard Windows Apps & Features uninstall entry.
package main

import (
    "embed"
    "fmt"
    "os"
    "os/exec"
    "path/filepath"
    "strings"
    "syscall"
    "unsafe"
)

//go:embed resources/CamberryPlan.exe resources/Uninstall.exe resources/camberry.ico
var files embed.FS

var (
    user32 = syscall.NewLazyDLL("user32.dll")
    kernel32 = syscall.NewLazyDLL("kernel32.dll")
    createWindowEx=user32.NewProc("CreateWindowExW")
    registerClassEx=user32.NewProc("RegisterClassExW")
    defWindowProc=user32.NewProc("DefWindowProcW")
    showWindow=user32.NewProc("ShowWindow")
    updateWindow=user32.NewProc("UpdateWindow")
    getMessage=user32.NewProc("GetMessageW")
    translateMessage=user32.NewProc("TranslateMessage")
    dispatchMessage=user32.NewProc("DispatchMessageW")
    postQuitMessage=user32.NewProc("PostQuitMessage")
    destroyWindow=user32.NewProc("DestroyWindow")
    sendMessage=user32.NewProc("SendMessageW")
    setWindowText=user32.NewProc("SetWindowTextW")
    enableWindow=user32.NewProc("EnableWindow")
    createFont=user32.NewProc("CreateFontW")
    getSysMetric=user32.NewProc("GetSystemMetrics")
    messageBox=user32.NewProc("MessageBoxW")
    getModuleHandle=kernel32.NewProc("GetModuleHandleW")
)

const (
  wmCreate=0x0001; wmDestroy=0x0002; wmClose=0x0010; wmCommand=0x0111
  wmSetFont=0x0030; bmGetCheck=0x00F0; bmSetCheck=0x00F1
  wsChild=0x40000000; wsVisible=0x10000000
  wsCaption=0x00C00000; wsSysMenu=0x00080000; wsMinimizeBox=0x00020000
  wsBorder=0x00800000; wsTabStop=0x00010000
  bsAutoCheckBox=0x0003; esReadOnly=0x0800
  idInstall=100; idCancel=101; idDesktop=102; idStart=103
  idInfo=104
  mbIconInformation=0x40
  windowWidth=605;windowHeight=385
)

type point struct { X,Y int32 }
type winMsg struct {
 Hwnd uintptr
 Message uint32
 WParam uintptr
 LParam uintptr
 Time uint32
 Pt point
 LPrivate uint32
}
type wndClassEx struct {
 CbSize uint32
 Style uint32
 WndProc uintptr
 ClsExtra int32
 WndExtra int32
 Instance uintptr
 Icon uintptr
 Cursor uintptr
 Background uintptr
 MenuName *uint16
 ClassName *uint16
 IconSm uintptr
}
func u(s string) *uint16 {return syscall.StringToUTF16Ptr(s)}
func callText(proc *syscall.LazyProc,hwnd uintptr,s string){proc.Call(hwnd,uintptr(unsafe.Pointer(u(s))))}
func popup(msg string,flags uintptr){messageBox.Call(0,uintptr(unsafe.Pointer(u(msg))),uintptr(unsafe.Pointer(u("CamberryPlan — установка"))),flags)}
func cmdRun(name string, args ...string) error {
 c:=exec.Command(name,args...);c.SysProcAttr=&syscall.SysProcAttr{HideWindow:true}
 return c.Run()
}
func qPS(text string)string{return "'"+strings.ReplaceAll(text,"'","''")+"'"}
func shortcut(target,location,icon,workingDir,description string) error{
 special:=qPS(location)
 // Resolve OneDrive-redirected Desktop and Start Menu folders correctly.
 if strings.HasSuffix(strings.ToLower(location),strings.ToLower(`\Desktop\CamberryPlan.lnk`)) {
  special=`([Environment]::GetFolderPath('DesktopDirectory') + '\CamberryPlan.lnk')`
 } else if strings.Contains(strings.ToLower(location),strings.ToLower(`\Start Menu\Programs\CamberryPlan.lnk`)) {
  special=`([Environment]::GetFolderPath('Programs') + '\CamberryPlan.lnk')`
 }
 script := "$w=New-Object -ComObject WScript.Shell;"+
 "$s=$w.CreateShortcut("+special+");"+
 "$s.TargetPath="+qPS(target)+";"+
 "$s.WorkingDirectory="+qPS(workingDir)+";"+
 "$s.IconLocation="+qPS(icon)+";"+
 "$s.Description="+qPS(description)+";"+
 "$s.Save();"
 return cmdRun("powershell.exe","-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",script)
}
func registerUninstall(dir string){
 key:=`HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\CamberryPlan`
 values:=[][3]string{
  {"DisplayName","REG_SZ","CamberryPlan"},
  {"Publisher","REG_SZ","CamberryMSK"},
  {"DisplayVersion","REG_SZ","0.5.0 Beta"},
  {"InstallLocation","REG_SZ",dir},
  {"DisplayIcon","REG_SZ",filepath.Join(dir,"camberry.ico")},
  {"UninstallString","REG_SZ",`"`+filepath.Join(dir,"Uninstall.exe")+`"`},
  {"NoModify","REG_DWORD","1"},
  {"NoRepair","REG_DWORD","1"},
 }
 for _,v:=range values {_=cmdRun("reg.exe","add",key,"/v",v[0],"/t",v[1],"/d",v[2],"/f")}
}
func installDir() string {return filepath.Join(os.Getenv("LOCALAPPDATA"),"Programs","CamberryPlan")}
func install(withDesktop bool) (string,error) {
 dir:=installDir()
 if dir==""||os.Getenv("LOCALAPPDATA")=="" {return "",fmt.Errorf("не найдена папка LocalAppData")}
 if err:=os.MkdirAll(dir,0755);err!=nil{return "",err}
 for _,file:=range []string{"CamberryPlan.exe","Uninstall.exe","camberry.ico"}{
  contents,err:=files.ReadFile("resources/"+file)
  if err!=nil{return "",err}
  if err:=os.WriteFile(filepath.Join(dir,file),contents,0644);err!=nil{return "",err}
 }
 exe:=filepath.Join(dir,"CamberryPlan.exe")
 icon:=filepath.Join(dir,"camberry.ico")
 programs:=filepath.Join(os.Getenv("APPDATA"),"Microsoft","Windows","Start Menu","Programs")
 if err:=shortcut(exe,filepath.Join(programs,"CamberryPlan.lnk"),icon,dir,"CamberryPlan — планировщик видеонаблюдения и сетей");err!=nil {
   // App is installed even when Windows PowerShell is disabled by company policy.
   popup("Приложение установлено, но не удалось создать ярлык в меню «Пуск».\nПроверьте настройки Windows PowerShell.",mbIconInformation)
 }
 if withDesktop {
  if err:=shortcut(exe,filepath.Join(os.Getenv("USERPROFILE"),"Desktop","CamberryPlan.lnk"),icon,dir,"CamberryPlan — планировщик видеонаблюдения и сетей");err!=nil {
   popup("Приложение установлено, но ярлык рабочего стола не создан.\nМожно открыть программу из меню «Пуск».",mbIconInformation)
  }
 }
 registerUninstall(dir)
 return exe,nil
}

var hwndMain,btnInstall,btnCancel,desktopCheck,statusLabel,description,dirLabel,headerLabel uintptr
var normalFont,titleFont uintptr
var ready bool
var installedExe string

func control(class,text string,x,y,w,h int,style uintptr,id uintptr)uintptr {
 hwnd,_,_:=createWindowEx.Call(0,uintptr(unsafe.Pointer(u(class))),uintptr(unsafe.Pointer(u(text))),style,
  uintptr(x),uintptr(y),uintptr(w),uintptr(h),hwndMain,id,0,0)
 if normalFont!=0{sendMessage.Call(hwnd,wmSetFont,normalFont,1)}
 return hwnd
}
func setCtrlText(hwnd uintptr,text string){callText(setWindowText,hwnd,text)}
func setFont(hwnd,font uintptr){sendMessage.Call(hwnd,wmSetFont,font,1)}
func makeFont(size,weight int)uintptr{
 face:=u("Segoe UI")
 r,_,_:=createFont.Call(uintptr(int32(-size)),0,0,0,uintptr(weight),0,0,0,1,0,0,5,0,uintptr(unsafe.Pointer(face)))
 return r
}
func setupControls(){
 normalFont=makeFont(17,400)
 titleFont=makeFont(28,700)
 headerLabel=control("STATIC","CamberryPlan",27,25,530,42,wsChild|wsVisible,0)
 setFont(headerLabel,titleFont)
 description=control("STATIC","Планировщик видеонаблюдения, сетей и слаботочных систем",29,76,540,30,wsChild|wsVisible,0)
 _=control("STATIC","Папка установки (для текущего пользователя):",29,130,540,28,wsChild|wsVisible,0)
 dirLabel=control("EDIT",installDir(),29,158,540,28,wsChild|wsVisible|wsBorder|esReadOnly,0)
 desktopCheck=control("BUTTON","Создать ярлык на рабочем столе",29,205,510,31,wsChild|wsVisible|bsAutoCheckBox|wsTabStop,idDesktop)
 sendMessage.Call(desktopCheck,bmSetCheck,1,0)
 statusLabel=control("STATIC","Программа работает без интернета. Требуется Microsoft Edge или Chrome.",29,252,540,28,wsChild|wsVisible,0)
 btnInstall=control("BUTTON","Установить",344,306,125,38,wsChild|wsVisible|wsTabStop,idInstall)
 btnCancel=control("BUTTON","Отмена",478,306,98,38,wsChild|wsVisible|wsTabStop,idCancel)
}
func doInstall(){
 enableWindow.Call(btnInstall,0)
 setCtrlText(statusLabel,"Устанавливается CamberryPlan...")
 checked,_,_:=sendMessage.Call(desktopCheck,bmGetCheck,0,0)
 exe,err:=install(checked==1)
 if err!=nil {
  popup("Не удалось установить CamberryPlan:\n"+err.Error(),0x10)
  setCtrlText(statusLabel,"Ошибка установки. Попробуйте снова.")
  enableWindow.Call(btnInstall,1)
  return
 }
 installedExe=exe;ready=true
 setCtrlText(headerLabel,"Установка завершена!")
 setCtrlText(description,"CamberryPlan готов к работе.")
 setCtrlText(statusLabel,"Приложение добавлено в меню «Пуск» и список установленных программ.")
 setCtrlText(btnInstall,"Запустить")
 setCtrlText(btnCancel,"Готово")
 enableWindow.Call(btnInstall,1)
}
func wndProc(hwnd uintptr,msg uint32,wparam,lparam uintptr)uintptr{
 switch msg {
 case wmCreate:
  hwndMain=hwnd
  setupControls()
  return 0
 case wmCommand:
  switch wparam&0xffff {
  case idInstall:
   if ready {
    c:=exec.Command(installedExe);c.SysProcAttr=&syscall.SysProcAttr{HideWindow:true}
    if err:=c.Start();err!=nil{popup("Не удалось запустить CamberryPlan: "+err.Error(),0x10)}
    destroyWindow.Call(hwnd)
   }else{doInstall()}
   return 0
  case idCancel:
   destroyWindow.Call(hwnd);return 0
  }
 case wmClose:
  destroyWindow.Call(hwnd);return 0
 case wmDestroy:
  postQuitMessage.Call(0);return 0
 }
 r,_,_:=defWindowProc.Call(hwnd,uintptr(msg),wparam,lparam)
 return r
}
func main(){
 instance,_,_:=getModuleHandle.Call(0)
 className:=u("CamberryPlanNativeSetup")
 cls:=wndClassEx{CbSize:uint32(unsafe.Sizeof(wndClassEx{})),WndProc:syscall.NewCallback(wndProc),Instance:instance,
  Background:uintptr(6),ClassName:className} // COLOR_WINDOW + 1
 if id,_,err:=registerClassEx.Call(uintptr(unsafe.Pointer(&cls)));id==0{
  popup("Не удалось запустить мастер установки: "+err.Error(),0x10);return
 }
 sw,_,_:=getSysMetric.Call(0);sh,_,_:=getSysMetric.Call(1)
 x,y:=int(sw)-windowWidth,int(sh)-windowHeight
 if x<0{x=0};if y<0{y=0}
 x/=2;y/=2
 hwnd,_,_:=createWindowEx.Call(0,uintptr(unsafe.Pointer(className)),uintptr(unsafe.Pointer(u("Установка CamberryPlan"))),
   wsCaption|wsSysMenu|wsMinimizeBox|wsVisible,uintptr(x),uintptr(y),windowWidth,windowHeight,0,0,instance,0)
 if hwnd==0 {popup("Не удалось открыть окно установки.",0x10);return}
 showWindow.Call(hwnd,1)
 updateWindow.Call(hwnd)
 var message winMsg
 for {
  ret,_,_:=getMessage.Call(uintptr(unsafe.Pointer(&message)),0,0,0)
  if int32(ret)<=0 {break}
  translateMessage.Call(uintptr(unsafe.Pointer(&message)))
  dispatchMessage.Call(uintptr(unsafe.Pointer(&message)))
 }
}
