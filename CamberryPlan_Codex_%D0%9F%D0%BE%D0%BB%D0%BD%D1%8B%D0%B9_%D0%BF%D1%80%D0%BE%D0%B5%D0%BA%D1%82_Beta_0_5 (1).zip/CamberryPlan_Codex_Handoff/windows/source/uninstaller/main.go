// Standard per-user uninstaller for CamberryPlan.
package main
import (
 "os"
 "os/exec"
 "path/filepath"
 "syscall"
 "unsafe"
 "fmt"
)
var user32=syscall.NewLazyDLL("user32.dll")
var messageBox=user32.NewProc("MessageBoxW")
func ask(text string) bool { t:=syscall.StringToUTF16Ptr(text); ttl:=syscall.StringToUTF16Ptr("Удаление CamberryPlan"); r,_,_:=messageBox.Call(0,uintptr(unsafe.Pointer(t)),uintptr(unsafe.Pointer(ttl)),0x24);return r==6}
func notice(text string) {t:=syscall.StringToUTF16Ptr(text);ttl:=syscall.StringToUTF16Ptr("CamberryPlan");messageBox.Call(0,uintptr(unsafe.Pointer(t)),uintptr(unsafe.Pointer(ttl)),0x40)}
func cmdRun(name string,args ...string){c:=exec.Command(name,args...);c.SysProcAttr=&syscall.SysProcAttr{HideWindow:true};_ =c.Run()}
func main(){
 if !ask("Удалить CamberryPlan с компьютера?\n\nЛокальные сохранения и проекты в папке пользователя останутся доступными.") {return}
 file,_:=os.Executable();folder:=filepath.Dir(file)
 user:=os.Getenv("USERPROFILE")
 appdata:=os.Getenv("APPDATA")
 // Delete only the shortcuts created for this application.
 _=os.Remove(filepath.Join(user,"Desktop","CamberryPlan.lnk"))
 _=os.Remove(filepath.Join(appdata,"Microsoft","Windows","Start Menu","Programs","CamberryPlan.lnk"))
 // Folder redirection / OneDrive may move Desktop; remove the real shortcuts as well.
 cleanupLinks:=`$p=@([Environment]::GetFolderPath('DesktopDirectory'),[Environment]::GetFolderPath('Programs'));`+
  `foreach($d in $p){Remove-Item -LiteralPath (Join-Path $d 'CamberryPlan.lnk') -Force -ErrorAction SilentlyContinue}`
 cmdRun("powershell.exe","-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",cleanupLinks)
 cmdRun("reg.exe","delete",`HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\CamberryPlan`,"/f")
 _=os.Remove(filepath.Join(folder,"CamberryPlan.exe"))
 _=os.Remove(filepath.Join(folder,"camberry.ico"))
 notice("CamberryPlan удалён.\n\nСохранённые проекты не удалялись.")
 // Remove the running uninstaller after it exits.
 cleanup:=fmt.Sprintf(`ping -n 3 127.0.0.1 >NUL & del /f /q "%s" & rd "%s"`,file,folder)
 c:=exec.Command("cmd.exe","/C",cleanup);c.SysProcAttr=&syscall.SysProcAttr{HideWindow:true};_ =c.Start()
}
