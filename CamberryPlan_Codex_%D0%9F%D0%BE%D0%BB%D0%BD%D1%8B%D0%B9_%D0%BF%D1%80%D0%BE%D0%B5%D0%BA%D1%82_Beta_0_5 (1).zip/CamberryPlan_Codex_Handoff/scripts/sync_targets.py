#!/usr/bin/env python3
"""Synchronize canonical HTML to Windows source and Android HTML-to-APK ZIP.

Usage:
    python scripts/sync_targets.py         # Update generated targets
    python scripts/sync_targets.py --check # Verify targets match canonical source

The Android ZIP is intended for the *third-party HTML to APK Builder*.
It is NOT a finished APK. This script does not build Windows EXE.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import argparse

ROOT = Path(__file__).resolve().parents[1]
CANON = ROOT / 'app' / 'index.html'
WINDOWS = ROOT / 'windows' / 'source' / 'app' / 'html' / 'index.html'
ANDROID = ROOT / 'android' / 'CamberryPlan_Beta_0_5_HTML_to_APK.zip'
ICON = ROOT / 'assets' / 'icon.png'

def verify_html(data: bytes) -> None:
    if b'<!doctype html>' not in data[:200].lower() or b'Camberry' not in data:
        raise RuntimeError('Canonical HTML did not pass basic identity checks')

def check():
    html = CANON.read_bytes()
    verify_html(html)
    assert WINDOWS.read_bytes() == html, f'Windows HTML mismatch: {WINDOWS}'
    with ZipFile(ANDROID) as z:
        assert z.read('index.html') == html, 'Android HTML mismatch'
        assert z.read('camberry_icon.png') == ICON.read_bytes(), 'Android icon mismatch'
    print('OK: Android ZIP and Windows embedded HTML match canonical app/index.html')
    print('SHA256:', sha256(html).hexdigest())

def build():
    html = CANON.read_bytes()
    verify_html(html)
    WINDOWS.parent.mkdir(parents=True, exist_ok=True)
    WINDOWS.write_bytes(html)
    ANDROID.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(ANDROID, 'w', compression=ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr('index.html', html)
        z.write(ICON, 'camberry_icon.png')
    check()
    print('Generated:', ANDROID)
    print('Updated:', WINDOWS)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    check() if args.check else build()
