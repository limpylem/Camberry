#!/usr/bin/env python3
"""Run Node syntax checks on all inline scripts in app/index.html.

This does not replace browser/device integration tests.
"""
from pathlib import Path
from html.parser import HTMLParser
import subprocess
import tempfile
import sys

ROOT = Path(__file__).resolve().parents[1]
class Extract(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.scripts=[]; self.in_script=False; self.buf=[]
    def handle_starttag(self, tag, attrs):
        if tag == 'script' and not dict(attrs).get('src'):
            self.in_script = True; self.buf = []
    def handle_data(self, text):
        if self.in_script:self.buf.append(text)
    def handle_endtag(self, tag):
        if tag=='script' and self.in_script:
            self.scripts.append(''.join(self.buf));self.in_script=False

s = Extract()
s.feed((ROOT/'app/index.html').read_text(encoding='utf8'))
assert s.scripts, 'No inline scripts found'
with tempfile.TemporaryDirectory() as tmp:
    for i, js in enumerate(s.scripts):
        file=Path(tmp)/f'inline_{i}.js'; file.write_text(js,encoding='utf8')
        run=subprocess.run(['node','--check',str(file)],capture_output=True,text=True)
        if run.returncode:
            print('JS syntax FAILED',i,run.stderr,file=sys.stderr)
            sys.exit(run.returncode)
        print(f'OK: inline JS script {i} ({len(js):,} chars)')
print('JavaScript syntax checks passed; browser interaction tests still needed.')
